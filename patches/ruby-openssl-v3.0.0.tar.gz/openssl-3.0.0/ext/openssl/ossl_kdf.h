#if !defined(OSSL_KDF_H)
#define OSSL_KDF_H

void Init_ossl_kdf(void);

#endif
